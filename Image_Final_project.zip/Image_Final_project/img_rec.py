import os
import cv2 as cv
import numpy as np 

people = ['2018-2-60-046','2018-2-60-048','2019-1-60-005','2019-1-60-024','2019-1-60-055',
'2019-1-60-060','2019-1-60-066','2019-1-60-075','2019-1-60-093','2019-1-60-094','2019-1-60-171',
'2019-1-60-172','2019-1-60-173','2019-1-60-174','2019-1-60-204']

p = []
DIR = r'D:\Image_processing\Image_Students_picture\Image_Students_picture\Faces\train'

haar_cascade = cv.CascadeClassifier('haar_code.xml')

features = []
labels = []

def create_train():
    for person in people:
        path = os.path.join(DIR,person)
        label = people.index(person)

        for img in os.listdir(path):
            img_path = os.path.join(path,img)

            img_array = cv.imread(img_path)
            gray = cv.cvtColor(img_array,cv.COLOR_BGR2GRAY)

            faces_rect = haar_cascade.detectMultiScale(gray, scaleFactor = 1.1, minNeighbors = 3)

            for(x,y,w,h) in faces_rect:
                faces_roi = gray[y:y+h, x:x+w]
                features.append(faces_roi)
                labels.append(label)

create_train()

print('Training done ------')

features = np.array(features, dtype='object')
labels = np.array(labels)

face_recognizer = cv.face.LBPHFaceRecognizer_create()

#train the recognizer on the features list and the labels list
face_recognizer.train(features,labels)

face_recognizer.save('face_trained.yml')
np.save('features.npy',features)
np.save('labels.npy',labels)

cv.waitKey(0)   


