import numpy as np 
import cv2 as cv 

haar_cascade = cv.CascadeClassifier('haar_code.xml')

people = ['2018-2-60-046','2018-2-60-048','2019-1-60-005','2019-1-60-024','2019-1-60-055',
'2019-1-60-060','2019-1-60-066','2019-1-60-075','2019-1-60-093','2019-1-60-094','2019-1-60-171',
'2019-1-60-172','2019-1-60-173','2019-1-60-174','2019-1-60-204']
'''features = np.load('features.npy', allow-pickle = True)
labels = np.load('labels.npy')'''

face_recognizer = cv.face.LBPHFaceRecognizer_create()
face_recognizer.read('face_trained.yml')

img = cv.imread(r'D:\Image_processing\Image_Students_picture\Image_Students_picture\Faces\val\2019-1-60-005_1\9.jpg')

gray = cv.cvtColor(img, cv.COLOR_BGR2GRAY)
cv.imshow('Person',gray)

#detect the face in the image
faces_rect = haar_cascade.detectMultiScale(gray, 1.1, 4)

for(x,y,w,h) in faces_rect:
    faces_roi = gray[y:y+h,x:x+h]

    label, confidence = face_recognizer.predict(faces_roi)
    print(f'Label = {people[label]} with a confidence of {confidence}')

    cv.putText(img, str(people[label]), (20,20), cv.FONT_HERSHEY_COMPLEX, 1.0, (0,255,0), thickness=2)
    cv.rectangle(img, (x,y), (x+w,y+h), (0,255,0), thickness= 2)

cv.imshow('Detected Face',img)

cv.waitKey(0)